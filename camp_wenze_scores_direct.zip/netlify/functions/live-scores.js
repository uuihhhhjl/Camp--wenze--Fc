exports.handler = async function () {
  const apiKey = process.env.API_FOOTBALL_KEY;
  if (!apiKey) {
    return { statusCode: 503, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify({ message: 'API_FOOTBALL_KEY is not configured' }) };
  }
  try {
    const upstream = await fetch('https://v3.football.api-sports.io/fixtures?live=all', {
      headers: { 'x-apisports-key': apiKey, 'Accept': 'application/json' }
    });
    const data = await upstream.json();
    if (!upstream.ok || (data.errors && Object.keys(data.errors).length)) {
      return { statusCode: 502, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify({ message: 'Football data provider returned an error' }) };
    }
    const matches = (data.response || []).map(item => ({
      league: item.league && item.league.name || 'Football',
      country: item.league && item.league.country || '',
      home: item.teams && item.teams.home && item.teams.home.name || 'Équipe domicile',
      away: item.teams && item.teams.away && item.teams.away.name || 'Équipe extérieure',
      homeScore: item.goals && item.goals.home != null ? item.goals.home : 0,
      awayScore: item.goals && item.goals.away != null ? item.goals.away : 0,
      status: item.fixture && item.fixture.status ? (item.fixture.status.elapsed != null ? item.fixture.status.elapsed + "' · " : '') + (item.fixture.status.long || 'En cours') : 'En direct'
    }));
    return { statusCode: 200, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=20' }, body: JSON.stringify({ matches }) };
  } catch (error) {
    return { statusCode: 502, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify({ message: 'Unable to reach football data provider' }) };
  }
};
